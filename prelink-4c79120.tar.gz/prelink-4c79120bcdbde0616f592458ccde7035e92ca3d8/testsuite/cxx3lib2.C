#include "cxx3.h"

A a2;
B b2;
C c;
