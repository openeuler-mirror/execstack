extern int baz ();

int
bar ()
{
  return baz ();
}
