#include "tls1.h"
#include <stdlib.h>

__thread struct A a1 = { 4, 5, 6 };
__thread struct A a2 = { 7, 8, 9 };
