#include "reloc1.h"

extern int f8 (void);
extern int f9 (void);
