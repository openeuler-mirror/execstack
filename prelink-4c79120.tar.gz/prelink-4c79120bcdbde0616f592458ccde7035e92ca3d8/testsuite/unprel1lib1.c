int
baz ()
{
  return 42;
}
