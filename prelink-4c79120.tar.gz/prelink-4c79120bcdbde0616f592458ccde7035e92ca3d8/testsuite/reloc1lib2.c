#include "reloc1.h"

int f1 (void)
{
  return 11;
}
